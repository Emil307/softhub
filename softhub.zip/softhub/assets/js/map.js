// Creating map options
let mapOptions = {
  center: [54.989346, 73.368203],
  zoom: 12,
  scrollWheelZoom: true,
};
// Creating a map object
let map = new L.map('map', mapOptions);
       
// Creating a Layer object
let layer = new L.TileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
});
       
// Adding layer to the map
map.addLayer(layer);
       
// Creating a marker
let marker = L.marker([54.950474, 73.389700]);
       
// Adding marker to the map
marker.addTo(map);

// Adding popup to the marker
marker.bindPopup('This is Tutorialspoint').openPopup();
marker.addTo(map); // Adding marker to the map