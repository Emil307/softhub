const regPopup = document.getElementById('reg-popup');
const regBtn = document.getElementById('signin');
const regClose = document.getElementById('close');

function add() {
  regPopup.classList.add('popup__active');
}

function remove() {
  regPopup.classList.remove('popup__active');
}

regBtn.onclick = add;
regClose.onclick = remove;