const popup = document.getElementById('add-popup');
const btn = document.getElementById('add');

function handleClick() {
  popup.classList.toggle('popup__active');
}

btn.onclick = handleClick;